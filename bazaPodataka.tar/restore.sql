--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.13 (Ubuntu 14.13-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.13 (Ubuntu 14.13-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "otvorenoRaculanstvo";
--
-- Name: otvorenoRaculanstvo; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "otvorenoRaculanstvo" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE "otvorenoRaculanstvo" OWNER TO postgres;

\connect "otvorenoRaculanstvo"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tram_stops; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tram_stops (
    id integer NOT NULL,
    name character varying,
    description character varying,
    note character varying,
    "coordinateX" double precision,
    "coordinateY" double precision,
    next_stop character varying,
    previous_stop character varying,
    date_built date
);


ALTER TABLE public.tram_stops OWNER TO postgres;

--
-- Name: tram_stops_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tram_stops_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tram_stops_id_seq OWNER TO postgres;

--
-- Name: tram_stops_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tram_stops_id_seq OWNED BY public.tram_stops.id;


--
-- Name: tram_stops_trams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tram_stops_trams (
    tram_id integer NOT NULL,
    tram_stop_id integer NOT NULL
);


ALTER TABLE public.tram_stops_trams OWNER TO postgres;

--
-- Name: trams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trams (
    id integer NOT NULL,
    route character varying
);


ALTER TABLE public.trams OWNER TO postgres;

--
-- Name: tram_stops id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tram_stops ALTER COLUMN id SET DEFAULT nextval('public.tram_stops_id_seq'::regclass);


--
-- Data for Name: tram_stops; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tram_stops (id, name, description, note, "coordinateX", "coordinateY", next_stop, previous_stop, date_built) FROM stdin;
\.
COPY public.tram_stops (id, name, description, note, "coordinateX", "coordinateY", next_stop, previous_stop, date_built) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: tram_stops_trams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tram_stops_trams (tram_id, tram_stop_id) FROM stdin;
\.
COPY public.tram_stops_trams (tram_id, tram_stop_id) FROM '$$PATH$$/3366.dat';

--
-- Data for Name: trams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trams (id, route) FROM stdin;
\.
COPY public.trams (id, route) FROM '$$PATH$$/3363.dat';

--
-- Name: tram_stops_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tram_stops_id_seq', 1, false);


--
-- Name: tram_stops pk_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tram_stops
    ADD CONSTRAINT pk_id PRIMARY KEY (id);


--
-- Name: tram_stops_trams tram_stops_trams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tram_stops_trams
    ADD CONSTRAINT tram_stops_trams_pkey PRIMARY KEY (tram_id, tram_stop_id);


--
-- Name: trams trams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trams
    ADD CONSTRAINT trams_pkey PRIMARY KEY (id);


--
-- Name: tram_stops_trams tram_stops_trams_tram_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tram_stops_trams
    ADD CONSTRAINT tram_stops_trams_tram_id_fkey FOREIGN KEY (tram_id) REFERENCES public.trams(id);


--
-- Name: tram_stops_trams tram_stops_trams_tram_stop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tram_stops_trams
    ADD CONSTRAINT tram_stops_trams_tram_stop_id_fkey FOREIGN KEY (tram_stop_id) REFERENCES public.tram_stops(id);


--
-- PostgreSQL database dump complete
--

